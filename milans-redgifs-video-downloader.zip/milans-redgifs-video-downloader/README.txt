Milan’s RedGifs Video Downloader v1.1.9
==============================

Milan’s RedGifs Video Downloader is part of the IT SUCKS! project. Save your
favorite videos and enjoy a little offline entertainment whenever you feel like it.

A lightweight Manifest V3 Chrome extension for downloading videos directly from
https://www.redgifs.com/ without using an external downloader service.

v1.1.8 focus
------------
Compatibility and lifecycle fixes following continued reports of scroll freezes.
A local component-reconciliation test reproduced an unlimited remove/reinsert
cycle in 1.1.7. Automatic control repair now stops after two removals, including
when the component replaces its video while removing the control. A short local
error-log entry explains when repair was stopped. A later media change after a
quiet period or toggling download buttons off/on can allow another attempt.
There is no repair polling timer.

Controls are created only for players within or near the viewport (240px margin)
and removed outside that area. Native IntersectionObserver entries supply size
information, avoiding synchronous layout reads across the entire feed. Wrappers
without their own layout box fall back to observing their actual video.

The document observer now watches added/removed nodes only. Attribute monitoring
is limited to nearby players/media and fullscreen navigation/its ancestors.
No global class watcher, scroll listener, scan timer or runtime dependency is
used. The old forced GPU transform on each download-button wrapper was removed.

Monitoring stops while disabled, hidden or leaving a page and resumes when
appropriate. Duplicate initialization cleans up the previous instance; detection
of an invalid extension context stops observers, listeners and pending work.
Fullscreen placement is unchanged; identical position values are not rewritten.
An overlapping download attempt no longer clears another attempt's active lock.

How it works
------------
1. The content script runs only on top-level https://www.redgifs.com/ pages.
2. It watches RedGIFs video players as the React/SPA interface updates.
3. It identifies the clip primarily from RedGIFs' current data-feed-item-id.
4. It also supports current/legacy player layouts including .Player, .PlayerV2,
   .TapTracker, .GifPreviewV2 and .tileItem through the actual <video> element.
5. On click it obtains a temporary RedGIFs API token.
6. It requests the clip metadata and prefers urls.hd, falling back to urls.sd.
7. Chrome downloads the signed RedGIFs media URL directly with Save As.
8. If the API resolver fails, an already-exposed direct RedGIFs MP4/WebM source
   in the clicked player is used as a fallback.

Permissions
-----------
- downloads: save the selected RedGIFs video.
- storage: remember whether download buttons are enabled.
- https://api.redgifs.com/*: resolve the current clip to its HD/SD media URL.

The content script itself matches only https://www.redgifs.com/*.
There is no <all_urls>, webRequest, offscreen document, external downloader,
analytics, tracking or remote executable code.

Player behavior
---------------
Visible/nearby RedGIFs players receive the 40px download button in the top-right
corner. Off-screen controls are removed and restored as players approach view.
The extension does not change position, dimensions, transform, opacity, overflow
or other layout styles on RedGIFs player containers. This is important because
the RedGIFs feed virtualizes/remounts video items while scrolling.

In RedGIFs' expanded/full-screen feed, the normal player button is hidden. A
separate fixed extension overlay is visually aligned with RedGIFs'
.fullScreenNav rail, but is not inserted into that rail or any RedGIFs fullscreen
container. Its position follows the live Close/Up control geometry and prefers
16px of clearance above and below the download button when the native gap allows
it. RedGIFs' own controls are never moved.

Install
-------
1. Open chrome://extensions.
2. Enable Developer mode.
3. Click Load unpacked and select this folder.
4. Open https://www.redgifs.com/ and use the download button in a video player.

When updating, keep only one copy enabled, reload the extension, then reload
all existing RedGIFs tabs. Previously injected 1.1.7 scripts remain in old pages
until those pages reload; the new version cannot retire their old closures.

Release notes
-------------
1.1.9: Version bump and Chrome Web Store ZIP packaging; extension behavior unchanged.

1.1.8: Limited control-repair loops, including component/video replacement.
       Created controls only near the viewport; removed forced GPU layers.
       Replaced global attribute monitoring with scoped observers.
       Added observer/listener cleanup for stale contexts, duplicate execution,
       disabled/hidden pages and page lifecycle changes.
       Preserved legacy boxless-player support and fullscreen positioning.
       Fixed ownership of the in-progress download lock on duplicate attempts.
1.1.7: Reduced repeated feed scanning and layout reads, filtered irrelevant
       class/extension UI mutations, and batched detached-player cleanup.
       Retained controls during DOM moves and repair after wrapper removal.
       Added temporary size observation for initially hidden/unready players.
       Stopped monitoring while disabled; preserved fullscreen positioning,
       download resolution, popup appearance and permissions.
1.1.6: Fixed collapsed popup width by explicitly sizing html/body to 340px
       and removing viewport-dependent width constraints. No script changes.
1.1.5: Refined popup spacing, card height, headings, links and dark-mode contrast.
       Matched the supplied 120 x 32px tip button, hover styling and soft pulse;
       added reduced-motion support. Replaced cloud branding with the supplied,
       unmodified rg-downloader.svg and regenerated 16/32/48/128px PNG icons.
       Disabled the settings toggle during initial loading and saving; failed
       saves restore the previous value and show a short local status message.
       Improved long error wrapping and clarified temporary log behavior.
       Removed focus-only visual effects; hover styles remain.
1.1.4: Final stability audit and packaging/documentation cleanup. Functional
       downloader and player behavior remains the tested 1.1.3 implementation.
1.1.3: Feed safety fix. The extension stopped changing position/style or adding
       marker attributes to RedGIFs player containers.
1.1.2: Fullscreen control moved into a separate fixed extension layer with 16px
       preferred spacing around the download control.

Icon source
-----------
icons/rg-downloader.svg is the canonical, unmodified supplied artwork.
The four icon-*.png files are rasterized from it with transparency preserved.
No build tools or runtime dependencies are required to use this extension.

Error log
---------
Errors are stored only in the service worker's memory, with up to 12 entries
per tab. They clear on page reload/tab close and may reset when Chrome stops
or restarts the worker. They are not saved to disk or sent to external services.

Revision checks
---------------
Chromium 153 tests used synthetic feed DOM and mocked Chrome messaging. They
covered wheel scrolling through retained feeds, 800 virtualized replacements,
hidden and legacy players, boxless wrappers, class-only player discovery on
interaction, repeated control/video removal, fullscreen placement, download
message/fallback paths, duplicate clicks, settings, page lifecycle, duplicate
initialization and invalidated-context shutdown.

In the repeated-removal fixture, 1.1.7 kept recreating a control each frame;
1.1.8 stopped after two removals and remained idle afterward. With 600 retained
players in an 800px-high viewport, 1.1.7 created 600 controls and made 600 player
layout reads; 1.1.8 created five nearby controls and made no synchronous player
layout reads. These are fixture results, not a live-site speed guarantee.

The real RedGIFs feed was unavailable in the test browser. The exact reported
live freeze, real API responses, Save As and media downloads were not verified
there. The API/download service worker, popup and permissions are unchanged.

If scrolling still freezes after updating and reloading the RedGIFs tab, disable
this extension completely and reload that same tab again for an A/B comparison.
This distinguishes extension-related behavior from a page/browser/media issue;
the extension does not change the site's own scrolling or media playback.
