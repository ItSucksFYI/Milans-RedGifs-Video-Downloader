"use strict";

(() => {
  const DEFAULT_SETTINGS = { downloadVideos: true };
  const MIN_PLAYER_WIDTH = 160;
  const MIN_PLAYER_HEIGHT = 90;
  const PLAYER_SELECTOR = ".Player, .PlayerV2, .TapTracker, .GifPreviewV2, .tileItem";
  const FULLSCREEN_NAV_SELECTOR = ".fullScreenNav";
  const FULLSCREEN_SLOT_CLASS = "rgvd-fullscreen-slot";
  const DISCOVERY_SELECTOR = `${PLAYER_SELECTOR}, video, ${FULLSCREEN_NAV_SELECTOR}`;
  const OWN_UI_SELECTOR = ".rgvd-button-wrap, .rgvd-fullscreen-slot, .rgvd-toast";
  const INSTANCE_KEY = "__rgvdContentCleanup";
  const MAX_CONTROL_REMOVALS = 2;
  const CONTROL_REPAIR_QUIET_MS = 2000;

  // Content scripts share this extension's isolated world, not the site's JS.
  // A second initialization must retire the previous observers and listeners.
  if (typeof globalThis[INSTANCE_KEY] === "function") globalThis[INSTANCE_KEY]();
  let stopped = false;
  let monitoring = false;
  const eventLifetime = new AbortController();

  let settings = { ...DEFAULT_SETTINGS };
  let nextButtonId = 1;
  let toastTimer = 0;
  const buttonStates = new Map();
  const activeDownloads = new Set();
  let fullscreenButtonState = null;
  let regularButtonsHidden = false;
  const fullscreenNavs = new Set();
  const buttonOwners = new WeakMap();
  const playerRecords = new Map();
  const viewportOwners = new WeakMap();
  const nearbyPlayers = new Set();
  const waitingForSize = new Set();
  let fullscreenRemovalCounts = new WeakMap();
  let repairWarningLogged = false;

  function extensionAlive() {
    if (stopped) return false;
    try {
      if (chrome.runtime?.id) return true;
    } catch {}
    dispose();
    return false;
  }

  async function runtimeMessage(payload) {
    if (!extensionAlive()) throw new Error("Reload this RedGIFs tab after updating the extension.");
    let response;
    try {
      response = await chrome.runtime.sendMessage(payload);
    } catch (error) {
      if (!chrome.runtime?.id || /context invalidated/i.test(String(error?.message || error))) dispose();
      throw error;
    }
    if (!response?.ok) throw new Error(response?.error || "Extension request failed.");
    return response;
  }

  function cleanError(error, fallback = "Unknown error.") {
    return String(error?.message || error || fallback)
      .replace(/https?:\/\/\S+/gi, "[URL]")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 280) || fallback;
  }

  function logError(message, detail = "") {
    runtimeMessage({
      type: "rgvd:record-error",
      message,
      detail: cleanError(detail, "")
    }).catch(() => {});
  }

  function toast(message, isError = false) {
    if (stopped) return;
    document.querySelector(".rgvd-toast")?.remove();
    clearTimeout(toastTimer);

    const node = document.createElement("div");
    node.className = `rgvd-toast${isError ? " rgvd-error" : ""}`;
    node.textContent = String(message || "");
    document.documentElement.appendChild(node);

    toastTimer = window.setTimeout(() => node.remove(), isError ? 6000 : 3200);
  }

  function onBackgroundMessage(message) {
    if (!extensionAlive()) return;
    if (message?.type !== "rgvd:background-error") return;
    const detail = message.detail ? ` ${message.detail}` : "";
    toast(`${message.message || "Download failed."}${detail}`, true);
  }

  chrome.runtime.onMessage.addListener(onBackgroundMessage);

  function sanitizeVideoId(value) {
    let id = String(value || "").trim();
    if (!id) return "";
    id = id
      .replace(/[?#].*$/, "")
      .replace(/\.(?:mp4|m4s|webm|webp|jpg|jpeg|png|gif)$/i, "")
      .replace(/(?:-(?:silent|mobile|large|small|poster))+$/i, "");
    return /^[a-z0-9]+$/i.test(id) ? id.toLowerCase() : "";
  }

  function idFromUrl(value) {
    try {
      const url = new URL(String(value || ""), location.href);
      const host = url.hostname.toLowerCase();
      if (!/(^|\.)redgifs\.com$/.test(host)) return "";

      const pageMatch = url.pathname.match(/^\/(?:watch|ifr)\/([^/?#]+)/i);
      if (pageMatch?.[1]) return sanitizeVideoId(pageMatch[1]);

      // Media CDN URLs carry the clip ID in the filename. Do not apply this
      // fallback to www/api paths, where a final segment such as "hd" could
      // otherwise be mistaken for a clip ID.
      if (host !== "redgifs.com" && host !== "www.redgifs.com" && host !== "api.redgifs.com") {
        const base = url.pathname.split("/").pop() || "";
        const id = sanitizeVideoId(base);
        if (id) return id;
      }
    } catch {}
    return "";
  }

  function pageVideoId() {
    return idFromUrl(location.href);
  }

  function isMainWatchPlayer(container) {
    if (!(container instanceof Element) || !pageVideoId()) return false;
    if (container.closest(".tileItem")) return false;
    return container.matches(".Player, .PlayerV2, .TapTracker, .GifPreviewV2") ||
      Boolean(container.closest(".Player, .PlayerV2, .TapTracker, .GifPreviewV2"));
  }

  function localFeedId(container) {
    if (!(container instanceof Element)) return "";

    const own = sanitizeVideoId(container.getAttribute("data-feed-item-id"));
    if (own) return own;

    const ancestor = container.closest("[data-feed-item-id]");
    const ancestorId = sanitizeVideoId(ancestor?.getAttribute("data-feed-item-id"));
    if (ancestorId) return ancestorId;

    const descendant = container.querySelector?.("[data-feed-item-id]");
    return sanitizeVideoId(descendant?.getAttribute("data-feed-item-id"));
  }

  function idFromVideo(video) {
    if (!(video instanceof HTMLVideoElement)) return "";

    const local = localFeedId(video);
    if (local) return local;

    for (const value of [video.poster, video.currentSrc, video.src]) {
      const id = idFromUrl(value);
      if (id) return id;
    }

    for (const source of video.querySelectorAll("source")) {
      const id = idFromUrl(source.src || source.getAttribute("src"));
      if (id) return id;
    }

    return "";
  }

  function videoIdForContainer(container) {
    // On a watch/ifr page the main player can be reused during SPA navigation.
    // The current page URL is the safest ground truth for that main player,
    // while feed/related tiles continue to use their local data-feed-item-id.
    const pageId = pageVideoId();
    if (pageId && isMainWatchPlayer(container)) return pageId;

    const local = localFeedId(container);
    if (local) return local;

    for (const attr of ["data-gif-id", "data-id", "data-video-id"]) {
      const id = sanitizeVideoId(container.getAttribute?.(attr));
      if (id) return id;
    }

    // Legacy RedGIFs layouts used IDs such as gif_ExampleClip.
    const legacyIdElement = container.id?.startsWith("gif_")
      ? container
      : (container.closest?.('[id^="gif_"]') || container.querySelector?.('[id^="gif_"]'));
    if (legacyIdElement?.id?.startsWith("gif_")) {
      const legacyId = sanitizeVideoId(legacyIdElement.id.slice(4));
      if (legacyId) return legacyId;
    }

    const anchor = container.closest?.('a[href*="/watch/"], a[href*="/ifr/"]') ||
      container.querySelector?.('a[href*="/watch/"], a[href*="/ifr/"]');
    const anchorId = idFromUrl(anchor?.href || anchor?.getAttribute?.("href"));
    if (anchorId) return anchorId;

    const videos = container.matches?.("video") ? [container] : [...(container.querySelectorAll?.("video") || [])];
    for (const video of videos) {
      const id = idFromVideo(video);
      if (id) return id;
    }

    if (pageId && videos.length <= 1) return pageId;

    for (const meta of document.querySelectorAll('meta[property="og:url"], meta[property="og:video"], meta[property="og:video:url"]')) {
      const id = idFromUrl(meta.getAttribute("content"));
      if (id) return id;
    }

    return "";
  }

  function isRedgifsMediaUrl(value) {
    try {
      const url = new URL(String(value || ""), location.href);
      return url.protocol === "https:" && /(^|\.)redgifs\.com$/i.test(url.hostname) && /\.(?:mp4|webm)(?:$|[?#])/i.test(url.pathname);
    } catch {
      return false;
    }
  }

  function directVideoSource(container) {
    const videos = container.matches?.("video") ? [container] : [...(container.querySelectorAll?.("video") || [])];
    const candidates = [];

    for (const video of videos) {
      for (const value of [video.currentSrc, video.src]) {
        if (isRedgifsMediaUrl(value)) candidates.push(value);
      }
      for (const source of video.querySelectorAll("source")) {
        const value = source.src || source.getAttribute("src") || "";
        if (isRedgifsMediaUrl(value)) candidates.push(value);
      }
    }

    return [...new Set(candidates)][0] || "";
  }

  function fallbackFilename(container, id, url) {
    let extension = "mp4";
    try {
      if (new URL(url).pathname.toLowerCase().endsWith(".webm")) extension = "webm";
    } catch {}
    return `RedGIFs - ${id || "video"}.${extension}`;
  }

  function canonicalContainer(element) {
    if (!(element instanceof Element)) return null;

    // Current RedGIFs layout first. A .Player may be nested in a gallery tile
    // or legacy wrapper, but it is the most useful place for the overlay.
    const currentPlayer = element.matches(".Player") ? element : element.closest(".Player");
    if (currentPlayer instanceof HTMLElement) return currentPlayer;

    for (const selector of [".PlayerV2", ".TapTracker"]) {
      const legacy = element.matches(selector) ? element : element.closest(selector);
      if (legacy instanceof HTMLElement) return legacy;
    }

    const preview = element.matches(".GifPreviewV2") ? element : element.closest(".GifPreviewV2");
    if (preview instanceof HTMLElement) {
      const inner = preview.querySelector(".Player, .PlayerV2, .TapTracker");
      if (inner instanceof HTMLElement) return inner;
      return preview;
    }

    const tile = element.matches(".tileItem") ? element : element.closest(".tileItem");
    if (tile instanceof HTMLElement) {
      const inner = tile.querySelector(".Player, .PlayerV2, .TapTracker");
      if (inner instanceof HTMLElement) return inner;
      return tile;
    }

    return null;
  }

  function findPlayerContainer(video) {
    if (!(video instanceof HTMLVideoElement)) return null;
    return canonicalContainer(video) ||
      (video.parentElement instanceof HTMLElement ? video.parentElement : null);
  }

  function containerHasDownloadableIdentity(container) {
    if (!(container instanceof HTMLElement)) return false;
    if (videoIdForContainer(container)) return true;
    return Boolean(container.querySelector("video"));
  }

  function isVisiblyRendered(element) {
    if (!(element instanceof HTMLElement) || !element.isConnected) return false;
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth;
  }

  function viewportIntersectionScore(element) {
    if (!(element instanceof HTMLElement) || !element.isConnected) return -Infinity;
    const rect = element.getBoundingClientRect();
    const width = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0));
    const height = Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
    const visibleArea = width * height;
    if (!visibleArea) return -Infinity;

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const distance = Math.hypot(centerX - innerWidth / 2, centerY - innerHeight / 2);
    let score = visibleArea - distance * 20;

    if (element.closest(".GifPreview_isActive")) score += 1e12;
    if (element.matches(".Player") || element.closest(".Player")) score += 1e9;
    return score;
  }

  function findActiveFullscreenContainer() {
    // Current RedGIFs fullscreen marks the active preview. Prefer it before
    // geometry so the correct clip wins even when neighboring feed items are
    // partly visible above/below the viewport.
    for (const selector of [
      ".GifPreview.GifPreview_isActive .Player",
      ".GifPreview_isActive .Player",
      ".GifPreview.GifPreview_isActive",
      ".GifPreview_isActive"
    ]) {
      for (const element of document.querySelectorAll(selector)) {
        const container = canonicalContainer(element) || (element instanceof HTMLElement ? element : null);
        if (container && isVisiblyRendered(container) && containerHasDownloadableIdentity(container)) return container;
      }
    }

    const candidates = new Set();
    for (const container of buttonStates.keys()) {
      if (container?.isConnected) candidates.add(container);
    }
    for (const element of document.querySelectorAll(PLAYER_SELECTOR)) {
      const container = canonicalContainer(element) || (element instanceof HTMLElement ? element : null);
      if (container) candidates.add(container);
    }

    let best = null;
    let bestScore = -Infinity;
    for (const container of candidates) {
      if (!containerHasDownloadableIdentity(container)) continue;
      const score = viewportIntersectionScore(container);
      if (score > bestScore) {
        best = container;
        bestScore = score;
      }
    }
    return best;
  }

  function stopSitePointerEvent(event) {
    event.stopPropagation();
    event.stopImmediatePropagation();
  }

  function wireDownloadButton(button, getContainer) {
    for (const eventName of ["pointerdown", "mousedown", "mouseup"]) {
      button.addEventListener(eventName, stopSitePointerEvent, true);
    }

    button.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      stopSitePointerEvent(event);
    }, true);

    button.addEventListener("click", (event) => {
      event.preventDefault();
      stopSitePointerEvent(event);
      const container = getContainer();
      if (!container) {
        toast("Could not identify the active RedGIFs video. Let it load, then try again.", true);
        return;
      }
      downloadFromContainer(button, container);
    }, true);
  }

  function fullscreenControlRects(nav) {
    const navRect = nav.getBoundingClientRect();
    const candidates = [];

    for (const element of nav.querySelectorAll("*")) {
      if (!(element instanceof HTMLElement)) continue;
      const rect = element.getBoundingClientRect();
      if (rect.width < 20 || rect.height < 20 || rect.width > 80 || rect.height > 80) continue;

      const centerX = rect.left + rect.width / 2;
      if (centerX < navRect.left - 8 || centerX > navRect.right + 8) continue;

      const style = getComputedStyle(element);
      const interactive = element.matches('button, a[href], [role="button"], [tabindex]') ||
        style.cursor === "pointer" || element.hasAttribute("aria-label") || element.hasAttribute("onclick");
      if (!interactive) continue;

      candidates.push({ rect, area: rect.width * rect.height });
    }

    // RedGIFs controls contain nested icon elements. Collapse boxes that
    // share almost the same vertical center so one native control is counted once.
    candidates.sort((a, b) => (a.rect.top + a.rect.height / 2) - (b.rect.top + b.rect.height / 2) || b.area - a.area);
    const unique = [];
    for (const candidate of candidates) {
      const center = candidate.rect.top + candidate.rect.height / 2;
      const existing = unique.find((item) => Math.abs((item.rect.top + item.rect.height / 2) - center) < 8);
      if (!existing) unique.push(candidate);
      else if (candidate.area > existing.area) Object.assign(existing, candidate);
    }

    return unique.map((item) => item.rect).sort((a, b) => a.top - b.top);
  }

  function setRegularButtonsHidden(hidden) {
    if (regularButtonsHidden === hidden) return;
    regularButtonsHidden = hidden;
    for (const state of buttonStates.values()) {
      state.wrap?.classList.toggle("rgvd-hidden-for-fullscreen", Boolean(hidden));
    }
  }

  function positionFullscreenButton(nav, slot) {
    if (!(nav instanceof HTMLElement) || !(slot instanceof HTMLElement) || !nav.isConnected || !slot.isConnected) return;

    const navRect = nav.getBoundingClientRect();
    const controls = fullscreenControlRects(nav);
    const buttonSize = 40;
    const desiredClearance = 16;
    let top;

    if (controls.length >= 2) {
      // Use the live gap between RedGIFs' Close and Up controls. Prefer at
      // least 16px of breathing room above and below our 40px button whenever
      // the native gap is large enough, otherwise simply center it safely.
      const rawStart = controls[0].bottom;
      const rawEnd = controls[1].top;
      const paddedStart = rawStart + desiredClearance;
      const paddedEnd = rawEnd - desiredClearance;

      if (paddedEnd - paddedStart >= buttonSize) {
        top = paddedStart + (paddedEnd - paddedStart - buttonSize) / 2;
      } else {
        top = (rawStart + rawEnd) / 2 - buttonSize / 2;
      }
    } else if (controls.length === 1) {
      top = controls[0].bottom + desiredClearance;
    } else {
      top = navRect.top + Math.max(0, navRect.height * 0.25 - buttonSize / 2);
    }

    const left = navRect.left + Math.max(0, (navRect.width - buttonSize) / 2);
    const nextTop = `${Math.round(top)}px`;
    const nextLeft = `${Math.round(left)}px`;
    if (slot.style.top !== nextTop) slot.style.top = nextTop;
    if (slot.style.left !== nextLeft) slot.style.left = nextLeft;
  }

  function removeFullscreenButton() {
    fullscreenButtonState?.slot?.remove();
    fullscreenButtonState = null;
    setRegularButtonsHidden(false);
  }

  function createFullscreenButton(nav) {
    removeFullscreenButton();

    const slot = document.createElement("div");
    slot.className = FULLSCREEN_SLOT_CLASS;
    slot.setAttribute("data-rgvd-fullscreen-control", "1");

    const button = document.createElement("button");
    button.className = "rgvd-fullscreen-button";
    button.type = "button";
    button.title = "Download RedGIFs video";
    button.setAttribute("aria-label", "Download RedGIFs video");

    const icon = document.createElement("img");
    icon.className = "rgvd-fullscreen-icon";
    icon.src = chrome.runtime.getURL("icons/rg-downloader.svg");
    icon.width = 40;
    icon.height = 40;
    icon.alt = "";
    icon.setAttribute("aria-hidden", "true");

    button.appendChild(icon);
    slot.appendChild(button);

    // Important: do not insert anything into RedGIFs' .fullScreenNav. It is
    // used only as a geometry anchor. Keeping our control in the extension's
    // own fixed layer avoids interfering with RedGIFs' fullscreen React/CSS.
    document.documentElement.appendChild(slot);
    fullscreenButtonState = { nav, slot, button };
    setRegularButtonsHidden(true);
    positionFullscreenButton(nav, slot);
    wireDownloadButton(button, findActiveFullscreenContainer);
  }

  function syncFullscreenButton() {
    if (!settings.downloadVideos) {
      removeFullscreenButton();
      return;
    }

    const nav = [...fullscreenNavs].find(isVisiblyRendered) || null;
    if (!nav || (fullscreenRemovalCounts.get(nav) || 0) >= MAX_CONTROL_REMOVALS) {
      removeFullscreenButton();
      return;
    }

    setRegularButtonsHidden(true);
    if (fullscreenButtonState?.nav === nav && fullscreenButtonState.slot?.isConnected) {
      positionFullscreenButton(nav, fullscreenButtonState.slot);
      return;
    }
    createFullscreenButton(nav);
  }

  function removeButton(container) {
    const state = buttonStates.get(container);
    if (!state) return;

    state.wrap?.remove();
    buttonStates.delete(container);
  }

  async function downloadFromContainer(button, container) {
    button.disabled = true;
    let activeId = "";
    try {
      const id = videoIdForContainer(container);

      if (id) {
        if (activeDownloads.has(id)) {
          toast("This RedGIFs video is already being prepared.");
          return;
        }
        activeDownloads.add(id);
        activeId = id;

        try {
          const response = await runtimeMessage({ type: "rgvd:download-redgifs", id });
          toast(`RedGIFs ${String(response.quality || "video").toUpperCase()} ready. Choose where to save it.`);
          return;
        } catch (error) {
          logError("RedGIFs API resolver failed; trying the player's direct video URL", error);
        }
      }

      const directUrl = directVideoSource(container);
      if (directUrl) {
        await runtimeMessage({
          type: "rgvd:download-url",
          url: directUrl,
          filename: fallbackFilename(container, id, directUrl)
        });
        toast("Video ready. Choose where to save it.");
        return;
      }

      if (!id) {
        throw new Error("Could not identify this RedGIFs clip. Let the video load, then try again.");
      }
      throw new Error("RedGIFs did not expose a downloadable video URL for this clip.");
    } catch (error) {
      logError("Video download failed", error);
      toast(`Download failed: ${cleanError(error, "The video could not be downloaded.")}`, true);
    } finally {
      if (activeId) activeDownloads.delete(activeId);
      button.disabled = false;
    }
  }

  function createButton(container) {
    if (buttonStates.has(container)) return;

    const id = String(nextButtonId++);

    // Do not alter RedGIFs' own positioning/layout. The feed virtualizes and
    // remounts .GifPreview/.TapTracker elements while scrolling, and changing
    // their positioning context can make RedGIFs leave only its blurred
    // backdrop visible. Our absolutely positioned child instead uses whatever
    // positioning context RedGIFs already provides.
    const wrap = document.createElement("div");
    wrap.className = regularButtonsHidden
      ? "rgvd-button-wrap rgvd-hidden-for-fullscreen"
      : "rgvd-button-wrap";
    buttonOwners.set(wrap, container);
    wrap.setAttribute("data-rgvd-owner", id);

    const button = document.createElement("button");
    button.className = "rgvd-button";
    button.type = "button";
    button.title = "Download RedGIFs video";
    button.setAttribute("aria-label", "Download RedGIFs video");

    const icon = document.createElement("img");
    icon.className = "rgvd-icon";
    icon.src = chrome.runtime.getURL("icons/rg-downloader.svg");
    icon.width = 40;
    icon.height = 40;
    icon.alt = "";
    icon.setAttribute("aria-hidden", "true");

    button.appendChild(icon);
    wrap.appendChild(button);
    container.appendChild(wrap);

    buttonStates.set(container, {
      id,
      wrap,
      button
    });

    wireDownloadButton(button, () => container);
  }

  let scanFrame = 0;
  let cleanupNeeded = false;
  let fullscreenDirty = false;
  let navDiscoveryNeeded = false;
  let playerTargetsDirty = false;
  let navTargetsDirty = false;
  const pendingRoots = new Set();
  const pendingPlayers = new Set();

  const viewportObserver = new IntersectionObserver((entries) => {
    if (!monitoring || !extensionAlive()) return;
    for (const entry of entries) {
      const container = viewportOwners.get(entry.target);
      const record = playerRecords.get(container);
      if (!record) continue;
      // Some legacy wrappers have no box (for example display: contents).
      // Observe the actual video in that case, without forcing a layout read.
      if (entry.target === container &&
          (entry.boundingClientRect.width < MIN_PLAYER_WIDTH || entry.boundingClientRect.height < MIN_PLAYER_HEIGHT)) {
        const video = container.querySelector("video");
        if (video) {
          observeViewport(container, video);
          continue;
        }
      }
      record.rect = entry.boundingClientRect;
      if (record.near === entry.isIntersecting) continue;
      record.near = entry.isIntersecting;
      if (record.near) nearbyPlayers.add(container);
      else nearbyPlayers.delete(container);
      pendingPlayers.add(container);
      playerTargetsDirty = true;
    }
    if (pendingPlayers.size) scheduleWork();
  }, { rootMargin: "240px 0px", threshold: 0 });

  const playerResizeObserver = new ResizeObserver((entries) => {
    if (!monitoring || !extensionAlive()) return;
    for (const entry of entries) {
      const container = viewportOwners.get(entry.target);
      if (!waitingForSize.has(container)) continue;
      const record = playerRecords.get(container);
      if (!record?.near) continue;
      record.rect = entry.contentRect;
      pendingPlayers.add(container);
    }
    if (pendingPlayers.size) scheduleWork();
  });

  function scheduleWork() {
    if (!monitoring || !extensionAlive() || scanFrame) return;
    scanFrame = requestAnimationFrame(flushWork);
  }

  function queueScan(node = document) {
    if (!monitoring || !node.isConnected) return;
    if (pendingRoots.has(document)) return;
    if (node === document) pendingRoots.clear();
    pendingRoots.add(node);
    scheduleWork();
  }

  function queueFullscreenSync(discover = false) {
    if (!monitoring) return;
    fullscreenDirty = true;
    navDiscoveryNeeded ||= discover;
    scheduleWork();
  }

  function trackPlayer(candidate, visited) {
    if (!(candidate instanceof HTMLElement) || !candidate.isConnected) return;
    const container = canonicalContainer(candidate) || candidate;
    if (visited.has(container)) return;
    visited.add(container);
    if (!playerRecords.has(container)) {
      // Observing visibility does not force every off-screen video to lay out.
      playerRecords.set(container, { near: false, rect: null, video: null, identity: "", removals: 0, lastRemovalAt: 0, viewportTarget: null });
      // An initially empty wrapper may now contain the actual player. Retire
      // its old control instead of leaving two controls on the same video.
      for (let parent = container.parentElement; parent; parent = parent.parentElement) {
        if (playerRecords.has(parent) && canonicalContainer(parent) === container) untrackPlayer(parent);
      }
      observeViewport(container, container);
    } else if (nearbyPlayers.has(container)) {
      pendingPlayers.add(container);
    }
  }

  function observeViewport(container, target) {
    const record = playerRecords.get(container);
    if (!record || record.viewportTarget === target) return;
    if (record.viewportTarget) {
      viewportObserver.unobserve(record.viewportTarget);
      playerResizeObserver.unobserve(record.viewportTarget);
      viewportOwners.delete(record.viewportTarget);
    }
    record.viewportTarget = target;
    record.near = false;
    record.rect = null;
    nearbyPlayers.delete(container);
    waitingForSize.delete(container);
    viewportOwners.set(target, container);
    viewportObserver.observe(target);
    playerTargetsDirty = true;
    pendingPlayers.add(container);
  }

  function scan(root, visited) {
    if (!root.isConnected) return;
    function discover(element) {
      if (element.matches(FULLSCREEN_NAV_SELECTOR) && !fullscreenNavs.has(element)) {
        fullscreenNavs.add(element);
        navTargetsDirty = true;
        fullscreenDirty = true;
      }
      if (element instanceof HTMLVideoElement) {
        const container = findPlayerContainer(element);
        if (container) trackPlayer(container, visited);
      } else if (element.matches(PLAYER_SELECTOR)) {
        trackPlayer(element, visited);
      }
    }
    if (root instanceof Element) discover(root);
    if (root.childElementCount) {
      for (const element of root.querySelectorAll(DISCOVERY_SELECTOR)) discover(element);
    }
  }

  function untrackPlayer(container) {
    const target = playerRecords.get(container)?.viewportTarget;
    if (target) {
      viewportObserver.unobserve(target);
      playerResizeObserver.unobserve(target);
      viewportOwners.delete(target);
    }
    waitingForSize.delete(container);
    nearbyPlayers.delete(container);
    pendingPlayers.delete(container);
    playerRecords.delete(container);
    removeButton(container);
    playerTargetsDirty = true;
  }

  function warnAboutControlRemoval() {
    if (repairWarningLogged) return;
    repairWarningLogged = true;
    logError("A download control was repeatedly removed by the page; automatic repair was stopped to protect scrolling");
  }

  function cleanupDetachedPlayers() {
    for (const [container, record] of playerRecords) {
      if (!container.isConnected) {
        untrackPlayer(container);
        continue;
      }
      if (!record.viewportTarget.isConnected) observeViewport(container, container);
      const state = buttonStates.get(container);
      if (state && (state.wrap.parentElement !== container || !state.button.isConnected)) {
        removeButton(container);
        record.removals += 1;
        record.lastRemovalAt = performance.now();
        if (record.removals >= MAX_CONTROL_REMOVALS) warnAboutControlRemoval();
        pendingPlayers.add(container);
      }
    }
    for (const nav of fullscreenNavs) {
      if (!nav.isConnected) {
        fullscreenNavs.delete(nav);
        navTargetsDirty = true;
        fullscreenDirty = true;
      }
    }
    if (fullscreenButtonState && (!fullscreenButtonState.slot.isConnected || !fullscreenButtonState.button.isConnected)) {
      const nav = fullscreenButtonState.nav;
      const removals = (fullscreenRemovalCounts.get(nav) || 0) + 1;
      fullscreenRemovalCounts.set(nav, removals);
      if (removals >= MAX_CONTROL_REMOVALS) warnAboutControlRemoval();
      removeFullscreenButton();
      fullscreenDirty = true;
    }
  }

  function updatePlayer(container) {
    const record = playerRecords.get(container);
    if (!record || !container.isConnected) return;
    if (!record.near) {
      removeButton(container);
      playerResizeObserver.unobserve(record.viewportTarget);
      waitingForSize.delete(container);
      return;
    }
    const video = container.matches("video") ? container : container.querySelector("video");
    const identity = localFeedId(container) || container.getAttribute("data-gif-id") ||
      container.getAttribute("data-video-id") || container.getAttribute("data-id") ||
      (video && (video.currentSrc || video.src || video.poster)) || "";
    if (video !== record.video || identity !== record.identity) {
      record.video = video;
      record.identity = identity;
      // A component may replace its video while removing our control. Such
      // replacement must not reset the repair limit every animation frame.
      if (performance.now() - record.lastRemovalAt >= CONTROL_REPAIR_QUIET_MS) record.removals = 0;
      playerTargetsDirty = true;
    }
    if (record.removals >= MAX_CONTROL_REMOVALS || buttonStates.has(container)) return;
    if (!video && !containerHasDownloadableIdentity(container)) return;
    if (!record.rect || record.rect.width < MIN_PLAYER_WIDTH || record.rect.height < MIN_PLAYER_HEIGHT) {
      if (!waitingForSize.has(container)) {
        waitingForSize.add(container);
        playerResizeObserver.observe(record.viewportTarget);
      }
      return;
    }
    if (waitingForSize.delete(container)) playerResizeObserver.unobserve(record.viewportTarget);
    createButton(container);
  }

  // Attribute observation is limited to nearby players/media and fullscreen
  // navigation. No document-wide class, source or player-state observer.
  const playerObserver = new MutationObserver((mutations) => {
    if (!monitoring || !extensionAlive()) return;
    for (const mutation of mutations) {
      for (const container of nearbyPlayers) {
        if (container === mutation.target || container.contains(mutation.target) || mutation.target.contains(container)) {
          pendingPlayers.add(container);
        }
      }
    }
    if (pendingPlayers.size) scheduleWork();
  });

  function refreshPlayerTargets() {
    playerObserver.disconnect();
    const targets = new Set();
    for (const container of nearbyPlayers) {
      targets.add(container);
      const feed = container.closest("[data-feed-item-id]");
      if (feed) targets.add(feed);
      const video = playerRecords.get(container)?.video;
      if (video) targets.add(video);
    }
    for (const target of targets) {
      playerObserver.observe(target, {
        attributes: true,
        attributeFilter: ["src", "poster", "data-feed-item-id", "data-gif-id", "data-id", "data-video-id"]
      });
    }
  }

  const navObserver = new MutationObserver(() => {
    if (extensionAlive()) queueFullscreenSync(true);
  });

  function refreshNavTargets() {
    navObserver.disconnect();
    const ancestors = new Set();
    for (const nav of fullscreenNavs) {
      for (let parent = nav.parentElement; parent; parent = parent.parentElement) ancestors.add(parent);
    }
    for (const parent of ancestors) {
      navObserver.observe(parent, { attributes: true, attributeFilter: ["class", "style", "hidden"] });
    }
    for (const nav of fullscreenNavs) {
      navObserver.observe(nav, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden"] });
    }
  }

  function flushWork() {
    scanFrame = 0;
    if (!monitoring || !extensionAlive()) return;
    if (cleanupNeeded) {
      cleanupNeeded = false;
      cleanupDetachedPlayers();
    }
    const roots = [...pendingRoots].filter((root) => {
      if (!root.isConnected) return false;
      for (let parent = root.parentNode; parent; parent = parent.parentNode) {
        if (pendingRoots.has(parent)) return false;
      }
      return true;
    });
    pendingRoots.clear();
    const visited = new Set();
    for (const root of roots) {
      try { scan(root, visited); }
      catch (error) { logError("RedGIFs page update could not be processed", error); }
    }
    for (const container of pendingPlayers) {
      try { updatePlayer(container); }
      catch (error) { logError("Download control could not be updated", error); }
      if (stopped) return;
    }
    pendingPlayers.clear();
    if (playerTargetsDirty) {
      playerTargetsDirty = false;
      refreshPlayerTargets();
    }
    if (navDiscoveryNeeded) {
      navDiscoveryNeeded = false;
      const current = new Set(document.querySelectorAll(FULLSCREEN_NAV_SELECTOR));
      if (current.size !== fullscreenNavs.size || [...current].some((nav) => !fullscreenNavs.has(nav))) {
        fullscreenNavs.clear();
        for (const nav of current) fullscreenNavs.add(nav);
        navTargetsDirty = true;
      }
    }
    if (navTargetsDirty) {
      navTargetsDirty = false;
      refreshNavTargets();
    }
    if (fullscreenDirty) {
      fullscreenDirty = false;
      try { syncFullscreenButton(); }
      catch (error) { logError("Fullscreen download control could not be updated", error); }
    }
  }

  const observer = new MutationObserver((mutations) => {
    if (!monitoring || !extensionAlive()) return;
    for (const mutation of mutations) {
      const target = mutation.target;
      if (!(target instanceof Element) || target.closest(OWN_UI_SELECTOR)) continue;
      for (const node of mutation.addedNodes) {
        if (!(node instanceof Element) || node.matches(OWN_UI_SELECTOR)) continue;
        queueScan(node.matches("source") ? (node.closest("video") || node) : node);
      }
      for (const node of mutation.removedNodes) {
        if (!(node instanceof Element)) continue;
        if (node.matches(OWN_UI_SELECTOR)) {
          const owner = buttonOwners.get(node);
          if ((owner && buttonStates.get(owner)?.wrap === node) || fullscreenButtonState?.slot === node) cleanupNeeded = true;
        } else cleanupNeeded = true;
      }
    }
    if (cleanupNeeded) scheduleWork();
  });

  function eventRescan(event) {
    if (event.target instanceof HTMLVideoElement) queueScan(event.target);
  }

  function discoverInteraction(event) {
    if (!monitoring || !(event.target instanceof Element)) return;
    const nav = event.target.closest(FULLSCREEN_NAV_SELECTOR);
    if (nav && !fullscreenNavs.has(nav)) queueScan(nav);
    const container = canonicalContainer(event.target);
    if (container && !playerRecords.has(container)) queueScan(container);
  }

  function discoverFullscreen() {
    queueFullscreenSync(true);
  }

  function refreshPage() {
    if (!extensionAlive() || !settings.downloadVideos || document.hidden) return;
    if (!monitoring) startMonitoring();
    else {
      queueScan(document);
      discoverFullscreen();
    }
  }

  function startMonitoring() {
    if (monitoring || !extensionAlive() || !settings.downloadVideos || document.hidden) return;
    monitoring = true;
    observer.observe(document.documentElement, { childList: true, subtree: true });
    queueScan(document);
    discoverFullscreen();
  }

  function stopMonitoring() {
    monitoring = false;
    observer.disconnect();
    playerObserver.disconnect();
    navObserver.disconnect();
    viewportObserver.disconnect();
    playerResizeObserver.disconnect();
    cancelAnimationFrame(scanFrame);
    scanFrame = 0;
    pendingRoots.clear();
    pendingPlayers.clear();
    nearbyPlayers.clear();
    waitingForSize.clear();
    playerRecords.clear();
    fullscreenNavs.clear();
    cleanupNeeded = fullscreenDirty = navDiscoveryNeeded = playerTargetsDirty = navTargetsDirty = false;
    for (const container of [...buttonStates.keys()]) removeButton(container);
    removeFullscreenButton();
  }

  function onSettingsChanged(changes, areaName) {
    if (!extensionAlive() || areaName !== "local" || !changes.downloadVideos) return;
    settings.downloadVideos = changes.downloadVideos.newValue !== false;
    if (settings.downloadVideos) {
      fullscreenRemovalCounts = new WeakMap();
      repairWarningLogged = false;
      startMonitoring();
    } else stopMonitoring();
  }

  function dispose() {
    if (stopped) return;
    stopped = true;
    stopMonitoring();
    eventLifetime.abort();
    clearTimeout(toastTimer);
    document.querySelector(".rgvd-toast")?.remove();
    try { chrome.storage.onChanged.removeListener(onSettingsChanged); } catch {}
    try { chrome.runtime.onMessage.removeListener(onBackgroundMessage); } catch {}
    if (globalThis[INSTANCE_KEY] === dispose) delete globalThis[INSTANCE_KEY];
  }

  async function init() {
    await runtimeMessage({ type: "rgvd:page-ready" }).catch(() => {});
    if (!extensionAlive()) return;
    try {
      const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
      settings.downloadVideos = stored.downloadVideos !== false;
    } catch (error) { logError("Extension settings could not be loaded", error); }
    if (!extensionAlive()) return;
    chrome.storage.onChanged.addListener(onSettingsChanged);
    const options = { capture: true, passive: true, signal: eventLifetime.signal };
    for (const eventName of ["loadedmetadata", "loadeddata", "canplay", "play", "durationchange"]) {
      document.addEventListener(eventName, eventRescan, options);
    }
    document.addEventListener("pointerover", discoverInteraction, options);
    document.addEventListener("click", discoverFullscreen, options);
    document.addEventListener("keyup", discoverFullscreen, options);
    document.addEventListener("fullscreenchange", discoverFullscreen, options);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) stopMonitoring();
      else refreshPage();
    }, options);
    window.addEventListener("resize", discoverFullscreen, options);
    window.addEventListener("pageshow", refreshPage, options);
    window.addEventListener("pagehide", stopMonitoring, options);
    window.addEventListener("popstate", refreshPage, options);
    startMonitoring();
  }

  globalThis[INSTANCE_KEY] = dispose;
  init().catch((error) => logError("Extension could not initialize", error));
})();
