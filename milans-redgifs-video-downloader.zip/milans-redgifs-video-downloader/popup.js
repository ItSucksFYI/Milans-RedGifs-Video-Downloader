"use strict";

(() => {
  const DEFAULT_SETTINGS = { downloadVideos: true };

  const infoView = document.getElementById("rgvd-info-view");
  const errorView = document.getElementById("rgvd-error-view");
  const errorList = document.getElementById("rgvd-error-list");
  const showErrors = document.getElementById("rgvd-show-errors");
  const backInfo = document.getElementById("rgvd-back-info");
  const videoToggle = document.getElementById("rgvd-download-videos");
  const versionNode = document.getElementById("rgvd-extension-version");
  const settingStatus = document.getElementById("rgvd-setting-status");

  function showSettingStatus(message = "") {
    settingStatus.textContent = message;
    settingStatus.hidden = !message;
  }

  function renderErrors(errors, unavailableMessage = "") {
    errorList.replaceChildren();
    if (unavailableMessage) {
      errorList.textContent = unavailableMessage;
      return;
    }
    if (!Array.isArray(errors) || errors.length === 0) {
      errorList.textContent = "No errors detected.";
      return;
    }

    for (const entry of errors) {
      const row = document.createElement("div");
      row.className = "rgvd-error-entry";

      const time = document.createElement("span");
      time.className = "rgvd-error-time";
      time.textContent = String(entry?.time || "");

      const message = document.createElement("span");
      message.textContent = String(entry?.message || "Extension error.");

      row.append(time, message);
      errorList.appendChild(row);
    }
  }

  async function readCurrentTabErrors() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return { errors: [], unavailable: "Error log unavailable: no active browser tab." };
      const response = await chrome.runtime.sendMessage({ type: "rgvd:get-error-log", tabId: tab.id });
      if (!response?.ok) return { errors: [], unavailable: "Error log unavailable on this tab." };
      return { errors: response.errors || [], unavailable: "" };
    } catch {
      return { errors: [], unavailable: "Error log unavailable on this tab." };
    }
  }

  async function loadSettings() {
    const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
    videoToggle.checked = stored.downloadVideos !== false;
  }

  async function saveSetting(value) {
    videoToggle.disabled = true;
    showSettingStatus();
    try {
      await chrome.storage.local.set({ downloadVideos: value });
    } catch (error) {
      videoToggle.checked = !value;
      showSettingStatus("Your setting could not be saved. Please try again.");
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.runtime.sendMessage({
          type: "rgvd:record-error",
          tabId: tab?.id,
          message: "Extension setting could not be saved",
          detail: error?.message || String(error || "Unknown error.")
        });
      } catch {}
    } finally {
      videoToggle.disabled = false;
    }
  }

  videoToggle.addEventListener("change", () => saveSetting(videoToggle.checked));

  showErrors.addEventListener("click", async (event) => {
    event.preventDefault();
    infoView.classList.add("rgvd-hidden");
    errorView.classList.remove("rgvd-hidden");
    errorList.textContent = "Checking...";
    const result = await readCurrentTabErrors();
    renderErrors(result.errors, result.unavailable);
  });

  backInfo.addEventListener("click", (event) => {
    event.preventDefault();
    errorView.classList.add("rgvd-hidden");
    infoView.classList.remove("rgvd-hidden");
  });

  async function init() {
    if (versionNode) versionNode.textContent = chrome.runtime.getManifest().version;
    try {
      await loadSettings();
      videoToggle.disabled = false;
    } catch {
      // Keep an unknown saved state read-only instead of presenting a guess.
      showSettingStatus("Settings could not be loaded. Please reopen this popup.");
    }
  }

  init();
})();
