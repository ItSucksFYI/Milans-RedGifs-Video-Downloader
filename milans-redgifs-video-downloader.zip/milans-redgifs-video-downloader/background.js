"use strict";

const MAX_ERROR_LOG_ENTRIES = 12;
const TOKEN_FALLBACK_TTL_MS = 23 * 60 * 60 * 1000;
const TOKEN_REFRESH_SAFETY_MS = 5 * 60 * 1000;
const API_TIMEOUT_MS = 10000;
const WINDOWS_RESERVED_BASENAME = /^(?:con|prn|aux|nul|clock\$|com[1-9]|lpt[1-9])(?:\.|$)/i;

const errorsByTab = new Map();
const startedDownloads = new Map();
let redgifsToken = "";
let redgifsTokenExpiresAt = 0;
let redgifsTokenRequest = null;

function cleanText(value, fallback = "Unknown error.") {
  return String(value || fallback)
    .replace(/https?:\/\/\S+/gi, "[URL]")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 320) || fallback;
}

function errorTime() {
  const now = new Date();
  return [now.getHours(), now.getMinutes(), now.getSeconds()]
    .map((part) => String(part).padStart(2, "0"))
    .join(":");
}

function logTabError(tabId, message, detail = "") {
  if (!Number.isInteger(tabId) || tabId < 0) return;
  const base = cleanText(message, "Extension error.");
  const extra = detail ? cleanText(detail, "") : "";
  const text = extra && extra !== base ? `${base}: ${extra}` : base;
  const entries = errorsByTab.get(tabId) || [];
  if (entries.at(-1)?.message === text) return;
  entries.push({ time: errorTime(), message: text });
  if (entries.length > MAX_ERROR_LOG_ENTRIES) {
    entries.splice(0, entries.length - MAX_ERROR_LOG_ENTRIES);
  }
  errorsByTab.set(tabId, entries);
}

chrome.tabs.onRemoved.addListener((tabId) => {
  errorsByTab.delete(tabId);
});

function isHttpUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

function isRedgifsMediaUrl(value) {
  try {
    const url = new URL(String(value || ""));
    return url.protocol === "https:" && /(^|\.)redgifs\.com$/i.test(url.hostname);
  } catch {
    return false;
  }
}

function validRedgifsId(value) {
  const id = String(value || "").trim().toLowerCase();
  return /^[a-z0-9]+$/.test(id) ? id : "";
}

function truncateUnicode(value, maxCharacters) {
  const text = String(value || "");
  if (typeof Intl?.Segmenter === "function") {
    const segmenter = new Intl.Segmenter(undefined, { granularity: "grapheme" });
    return [...segmenter.segment(text)]
      .slice(0, maxCharacters)
      .map((entry) => entry.segment)
      .join("");
  }
  return Array.from(text).slice(0, maxCharacters).join("");
}

function sanitizeFilenameBase(value, fallback = "redgifs-video") {
  let safe = String(value || fallback)
    .replace(/[<>:"/\\|?*%\x00-\x1F\x7F-\x9F]/g, "_")
    .replace(/^[.\s]+/g, "")
    .replace(/[.\s]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
  safe = truncateUnicode(safe, 160);
  if (!safe) safe = fallback;
  if (WINDOWS_RESERVED_BASENAME.test(safe)) safe = `_${safe}`;
  return safe;
}

function sanitizeVideoFilename(value, extension = "mp4") {
  const ext = String(extension || "mp4").toLowerCase() === "webm" ? "webm" : "mp4";
  const raw = String(value || `redgifs-video.${ext}`);
  const stem = raw.replace(/\.(?:mp4|webm|m4v|mov)$/i, "");
  return `${sanitizeFilenameBase(stem)}.${ext}`;
}

function mediaExtension(url) {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    return pathname.endsWith(".webm") ? "webm" : "mp4";
  } catch {
    return "mp4";
  }
}

function tokenExpiryFromJwt(token) {
  try {
    const payload = String(token || "").split(".")[1];
    if (!payload) return 0;
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const data = JSON.parse(atob(padded));
    const exp = Number(data?.exp);
    return Number.isFinite(exp) && exp > 0 ? exp * 1000 : 0;
  } catch {
    return 0;
  }
}

async function fetchJson(url, options = {}, timeoutMs = API_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      ...options,
      cache: "no-store",
      signal: controller.signal
    });
    if (!response.ok) {
      const error = new Error(`Request failed with HTTP ${response.status}.`);
      error.status = response.status;
      throw error;
    }
    return await response.json();
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("RedGIFs API request timed out.");
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function resetToken() {
  redgifsToken = "";
  redgifsTokenExpiresAt = 0;
}

async function getRedgifsToken(forceRefresh = false) {
  const now = Date.now();
  if (!forceRefresh && redgifsToken && now < redgifsTokenExpiresAt - TOKEN_REFRESH_SAFETY_MS) {
    return redgifsToken;
  }

  // Feed pages can expose many buttons at once. Share one in-flight token
  // request so quick consecutive clicks do not create needless auth calls.
  if (redgifsTokenRequest) return redgifsTokenRequest;

  const request = (async () => {
    const startedAt = Date.now();
    const data = await fetchJson("https://api.redgifs.com/v2/auth/temporary");
    const token = String(data?.token || "");
    if (!token) throw new Error("RedGIFs did not return a temporary API token.");

    const jwtExpiry = tokenExpiryFromJwt(token);
    redgifsToken = token;
    redgifsTokenExpiresAt = jwtExpiry > startedAt ? jwtExpiry : startedAt + TOKEN_FALLBACK_TTL_MS;
    return token;
  })();

  redgifsTokenRequest = request;
  try {
    return await request;
  } finally {
    if (redgifsTokenRequest === request) redgifsTokenRequest = null;
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchRedgifsInfo(id) {
  let forceTokenRefresh = false;
  let lastError = null;

  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const token = await getRedgifsToken(forceTokenRefresh);
      forceTokenRefresh = false;
      const data = await fetchJson(`https://api.redgifs.com/v2/gifs/${encodeURIComponent(id)}?views=yes`, {
        headers: {
          "Authorization": `Bearer ${token}`,
          "X-CustomHeader": `https://www.redgifs.com/watch/${id}`
        }
      });
      if (data?.error) throw new Error(`RedGIFs API: ${cleanText(data.error, "Unknown API error.")}`);
      return data;
    } catch (error) {
      lastError = error;
      const status = Number(error?.status) || 0;
      if (status === 401 && attempt < 2) {
        resetToken();
        forceTokenRefresh = true;
        continue;
      }
      if ((status === 429 || status >= 500) && attempt < 2) {
        await sleep(350 * (2 ** attempt) + Math.floor(Math.random() * 180));
        continue;
      }
      throw error;
    }
  }

  throw lastError || new Error("RedGIFs video information could not be loaded.");
}

function redgifsFilename(gif, id) {
  const tags = Array.isArray(gif?.tags)
    ? gif.tags.filter((tag) => typeof tag === "string" && tag.trim()).slice(0, 6).join(" ")
    : "";
  const uploader = String(gif?.userName || "").trim();
  const width = Number(gif?.width) || 0;
  const height = Number(gif?.height) || 0;
  const pieces = [];

  if (tags) pieces.push(tags);
  if (uploader) pieces.push(uploader);
  pieces.push(id);
  if (width > 0 && height > 0) pieces.push(`${width}x${height}`);

  return `${pieces.join(" - ")}.mp4`;
}

async function resolveRedgifs(rawId) {
  const id = validRedgifsId(rawId);
  if (!id) throw new Error("Could not identify this RedGIFs video.");

  const data = await fetchRedgifsInfo(id);
  const gif = data?.gif;
  if (!gif || typeof gif !== "object") throw new Error("RedGIFs returned no video information.");
  if (Number(gif.type) === 2) throw new Error("This RedGIFs item is an image, not a video.");

  const candidates = [gif?.urls?.hd, gif?.urls?.sd]
    .map((url) => String(url || ""))
    .filter((url) => isRedgifsMediaUrl(url));

  const url = candidates[0] || "";
  if (!url) throw new Error("RedGIFs did not expose an HD or SD video URL.");

  return {
    id,
    url,
    filename: redgifsFilename(gif, id),
    quality: gif?.urls?.hd === url ? "hd" : "sd"
  };
}

function isInvalidFilenameError(error) {
  return /invalid filename|file name too long/i.test(String(error?.message || error || ""));
}

async function startDownload({ url, filename }, sender) {
  if (!isHttpUrl(url) || !isRedgifsMediaUrl(url)) {
    throw new Error("Refusing to download a media URL outside RedGIFs.");
  }

  const extension = mediaExtension(url);
  const safeName = sanitizeVideoFilename(filename, extension);
  let downloadId;

  try {
    downloadId = await chrome.downloads.download({
      url,
      filename: safeName,
      saveAs: true
    });
  } catch (error) {
    if (!isInvalidFilenameError(error)) throw error;
    downloadId = await chrome.downloads.download({
      url,
      filename: `redgifs-video.${extension}`,
      saveAs: true
    });
  }

  if (Number.isInteger(sender?.tab?.id)) {
    startedDownloads.set(downloadId, {
      tabId: sender.tab.id,
      frameId: Number.isInteger(sender.frameId) ? sender.frameId : 0
    });
  }

  return { downloadId };
}

chrome.downloads.onChanged.addListener((delta) => {
  const tracked = startedDownloads.get(delta.id);
  if (!tracked) return;

  if (delta.state?.current === "complete") {
    startedDownloads.delete(delta.id);
    return;
  }

  if (delta.state?.current === "interrupted") {
    startedDownloads.delete(delta.id);
    const detail = delta.error?.current || "Chrome reported an interrupted download.";
    logTabError(tracked.tabId, "Download was interrupted", detail);
    try {
      chrome.tabs.sendMessage(tracked.tabId, {
        type: "rgvd:background-error",
        message: "Download was interrupted.",
        detail
      }).catch(() => {});
    } catch {}
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  const respond = async () => {
    if (message.type === "rgvd:page-ready") {
      if (Number.isInteger(sender?.tab?.id)) errorsByTab.delete(sender.tab.id);
      return { ok: true };
    }

    if (message.type === "rgvd:download-redgifs") {
      const resolved = await resolveRedgifs(message.id);
      const result = await startDownload(resolved, sender);
      return { ok: true, quality: resolved.quality, ...result };
    }

    if (message.type === "rgvd:download-url") {
      const result = await startDownload(message, sender);
      return { ok: true, ...result };
    }

    if (message.type === "rgvd:record-error") {
      const tabId = sender?.tab?.id ?? message.tabId;
      logTabError(tabId, message.message || "Extension error.", message.detail || "");
      return { ok: true };
    }

    if (message.type === "rgvd:get-error-log") {
      const tabId = Number(message.tabId);
      return {
        ok: true,
        errors: (errorsByTab.get(tabId) || []).map((entry) => ({ ...entry }))
      };
    }

    return { ok: false, error: "Unknown extension request." };
  };

  respond()
    .then(sendResponse)
    .catch((error) => {
      const tabId = sender?.tab?.id ?? message.tabId;
      if (Number.isInteger(tabId)) {
        logTabError(tabId, "Extension request failed", error?.message || error);
      }
      sendResponse({
        ok: false,
        error: cleanText(error?.message || error, "Extension request failed.")
      });
    });

  return true;
});
